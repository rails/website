ActionController::Base.send :include, InPlaceEditing
ActionController::Base.helper InPlaceMacrosHelper